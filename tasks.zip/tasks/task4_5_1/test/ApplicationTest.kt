// Task 4.5.1: Ktor application testing

import io.kotest.core.spec.style.FreeSpec
import io.kotest.matchers.shouldBe
import io.kotest.matchers.string.shouldContain
import io.ktor.client.request.get
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpStatusCode
import io.ktor.server.testing.testApplication

@Suppress("Unused")
class ApplicationTest : FreeSpec({
    "Path / yields 'Hello World!' greeting" {
        testApplication {
            configure()
            val response = client.get("/")
            response.status shouldBe HttpStatusCode.OK
            response.headers["Content-Type"]?.shouldContain("text/plain")
            response.bodyAsText() shouldBe "Hello World!"
        }
    }

    "Path /hello/Alice yields greeting for Alice" {
        testApplication {
            configure()
            val response = client.get("/hello/Alice")
            response.status shouldBe HttpStatusCode.OK
            response.headers["Content-Type"]?.shouldContain("text/plain")
            response.bodyAsText() shouldBe "Hello Alice!"
        }
    }

    "Path /hello/Bob yields greeting for Bob" {
        testApplication {
            configure()
            val response = client.get("/hello/Bob")
            response.status shouldBe HttpStatusCode.OK
            response.headers["Content-Type"]?.shouldContain("text/plain")
            response.bodyAsText() shouldBe "Hello Bob!"
        }
    }

    "Path /hello/ yields 404 Not Found" {
        testApplication {
            configure()
            val response = client.get("/hello/")
            response.status shouldBe HttpStatusCode.NotFound
        }
    }
})
