// Task 4.7

import io.ktor.server.application.*
import io.ktor.server.pebble.*
import io.ktor.server.request.*
import io.ktor.server.routing.*

fun Application.configureRouting() {
    routing {
        get("/") {
            call.respondTemplate("form.peb", emptyMap())
        }

        post("/roll") {
            val params = call.receiveParameters()
            val numDice = params["num_dice"]?.toInt() ?: 1
            val dieSides = params["die_sides"]?.toInt() ?: 6
            val roll = DiceRoll(numDice, dieSides)
            val context = mapOf("roll" to roll)
            call.respondTemplate("result.peb", context)
        }

        get("/roll/{rollSpec}") {
            val rollSpec = call.parameters["rollSpec"] ?: "1d6"
            val parts = rollSpec.split('d')
            val numDice = parts.getOrNull(0)?.toIntOrNull() ?: 1
            val dieSides = parts.getOrNull(1)?.toIntOrNull() ?: 6
            val roll = DiceRoll(numDice, dieSides)
            val context = mapOf("roll" to roll)
            call.respondTemplate("result.peb", context)
        }
    }
}
