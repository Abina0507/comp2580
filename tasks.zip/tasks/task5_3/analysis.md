# Colour Contrast Analysis

## Relative Luminances

The text has a relative luminance of 0.1434.

The background colour's relative luminance is 0.8297.

## Contrast Ratio

The page has a contrast ratio of 4.55:1.

## Conclusion

The page satisfies WCAG 1.4.3 (Contrast Minimum, Level AA), which requires a minimum contrast ratio of 4.5:1 for standard body text.

However, it does not satisfy WCAG 1.4.6 (Contrast Enhanced, Level AAA), which requires a contrast ratio of at least 7:1 for normal text.
