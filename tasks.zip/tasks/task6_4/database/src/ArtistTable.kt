// Task 6.4: creating database tables

import org.jetbrains.exposed.v1.core.dao.id.IntIdTable

const val MAX_VARCHAR_LENGTH = 256

object ArtistTable : IntIdTable() {
    val artistName = varchar("name", MAX_VARCHAR_LENGTH).uniqueIndex()
    val isSolo = bool("is_solo").default(false)
    val info = varchar("info_url", MAX_VARCHAR_LENGTH).nullable()
}
