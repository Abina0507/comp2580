// Task 6.5: populating database tables using Exposed's SQL DSL

import org.jetbrains.exposed.v1.jdbc.*
import org.jetbrains.exposed.v1.jdbc.transactions.transaction

fun main() {
    transaction(MusicDatabase.db) {
        SchemaUtils.drop(ArtistTable, AlbumTable)
        SchemaUtils.create(ArtistTable, AlbumTable)

        val beatles = ArtistTable.insertAndGetId {
            it[artistName] = "The Beatles"
            it[isSolo] = false
        }

        val bowie = ArtistTable.insertAndGetId {
            it[artistName] = "David Bowie"
            it[isSolo] = true
        }

        val pinkFloyd = ArtistTable.insertAndGetId {
            it[artistName] = "Pink Floyd"
            it[isSolo] = false
        }

        AlbumTable.insert {
            it[title] = "Abbey Road"
            it[artist] = beatles
            it[year] = 1969
        }

        AlbumTable.insert {
            it[title] = "Heroes"
            it[artist] = bowie
            it[year] = 1977
        }

        AlbumTable.insert {
            it[title] = "The Dark Side of the Moon"
            it[artist] = pinkFloyd
            it[year] = 1973
        }

        AlbumTable.insert {
            it[title] = "The Wall"
            it[artist] = pinkFloyd
            it[year] = 1979
        }
    }
}
