// Task 6.5: querying a database using Exposed's SQL DSL

import org.jetbrains.exposed.v1.core.*
import org.jetbrains.exposed.v1.jdbc.*
import org.jetbrains.exposed.v1.jdbc.transactions.transaction

fun main() {
    val numArtists = transaction(MusicDatabase.db) {
        ArtistTable.selectAll().count()
    }
    println("Number of artists: $numArtists")

    val numAlbums = transaction {
        AlbumTable.selectAll().count()
    }
    println("Number of albums: $numAlbums")

    transaction {
        println("\nBands in the database:")
        ArtistTable
            .selectAll()
            .where { ArtistTable.isSolo eq false }
            .forEach {
                println("- ${it[ArtistTable.artistName]}")
            }

        println("\nAlbums released after 1975:")
        (ArtistTable innerJoin AlbumTable)
            .selectAll()
            .where { AlbumTable.year greater 1975 }
            .forEach {
                val artist = it[ArtistTable.artistName]
                val title = it[AlbumTable.title]
                val year = it[AlbumTable.year]
                println("$artist - $title ($year)")
            }
    }
}
