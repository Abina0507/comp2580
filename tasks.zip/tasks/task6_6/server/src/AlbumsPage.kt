// Task 6.7

import io.ktor.server.pebble.*
import io.ktor.server.routing.*
import org.jetbrains.exposed.v1.jdbc.transactions.suspendTransaction

suspend fun RoutingCall.albumsPage() {
    suspendTransaction {
        val albums = Album.all().sortedWith(compareBy({ it.artist.name }, { it.year }))
        val context = mapOf("albums" to albums)
        respondTemplate("albums.peb", context)
    }
}
